module com.example.uicontrols {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.uicontrols to javafx.fxml;
    exports com.example.uicontrols;
}