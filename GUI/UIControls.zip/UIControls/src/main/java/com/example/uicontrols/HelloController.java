package com.example.uicontrols;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;

import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    @FXML
    private RadioButton reggaetonRB;

    @FXML
    private RadioButton salsaRB;

    @FXML
    private RadioButton metalRB;

    @FXML
    private ChoiceBox<String> countryCB;

    @FXML
    private RadioButton cumbiaRB;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        countryCB.setValue("Selecciona tu país");
        countryCB.getItems().addAll(
                "Colombia","México","Argentina", "Brasil"
        );
        countryCB.getSelectionModel().selectedIndexProperty().addListener(
                (value, oldValue, newValue)->{
                    System.out.println(newValue);
                    String country = countryCB.getItems().get(newValue.intValue());
                    System.out.println(country);
                }
        );
    }
}