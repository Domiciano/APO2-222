package com.example.ti3intro.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Avatar {

    private Canvas canvas;
    private GraphicsContext gc;

    public Avatar(Canvas canvas){
        this.canvas = canvas;
        gc = canvas.getGraphicsContext2D();
    }

    private int x=250;
    private int y=250;

    public void draw(){
        gc.setFill(Color.RED);
        gc.fillOval(x,y,50,50);

    }
    public void setPosition(double x, double y) {
        this.x = (int) x - 25;
        this.y = (int) y - 25;
    }

    public void moveVertical(int i) {
        this.y += i;
    }

    public void moveHorizontal(int i) {
        this.x += i;
    }
}
