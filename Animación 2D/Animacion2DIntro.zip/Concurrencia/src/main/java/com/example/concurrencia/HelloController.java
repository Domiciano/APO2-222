package com.example.concurrencia;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;

import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Canvas canvas;
    private GraphicsContext gc;

    @FXML
    private Label counterLabel;

    private int x = 0;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        runCounter();
        gc = canvas.getGraphicsContext2D();
        paint();
    }

    public void paint(){
        new Thread(
                ()->{
                    while(true){
                        Platform.runLater(()->{
                            gc.setFill(Color.rgb(0,0,0));
                            gc.fillRect(0,0, canvas.getWidth(), canvas.getHeight());

                            gc.setFill(Color.rgb(255,0,0));
                            gc.fillRect(x,50, 50,50);

                            gc.setFill(Color.rgb(0,0,255));
                            gc.fillOval(100,100, 50,50);
                        });
                        x++;
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
        ).start();
    }

    public void runCounter() {
        new Thread(
                () -> {
                    for (int i = 0; true; i++) {
                        System.out.println(i);


                        int finalI = i;
                        Platform.runLater(()->{
                            counterLabel.setText(""+ finalI);
                        });


                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
        ).start();
        System.out.println("Hola mundo!");


    }

}
