package com.example.tablas;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class UserData {

    private static UserData instance;
    public static UserData getInstance(){
        if(instance == null){
            instance = new UserData();
        }
        return instance;
    }

    private ObservableList<User> users;

    private UserData(){
        users = FXCollections.observableArrayList();
        users.add(new User("Alfa","Alfa123",34.2));
        users.add(new User("Beta","Beta123",14.2));
    }

    public ObservableList<User> getUsers() {
        return users;
    }
}
