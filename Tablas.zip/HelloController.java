package com.example.tablas;

import com.example.tablas.User;
import com.example.tablas.UserData;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private TableView<User> scoreTable;

    @FXML
    private TableColumn<User, String> idTC;

    @FXML
    private TableColumn<User, Double> scoreTC;

    @FXML
    private TableColumn<User, String> usernameTC;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idTC.setCellValueFactory(
                new PropertyValueFactory<>("id")
        );
        usernameTC.setCellValueFactory(
                new PropertyValueFactory<>("username")
        );
        scoreTC.setCellValueFactory(
                new PropertyValueFactory<>("score")
        );
        scoreTable.setItems(
                UserData.getInstance().getUsers()
        );
    }

    @FXML
    void addScore(ActionEvent event) {
        try {
            TextInputDialog idDialog = new TextInputDialog("Identificación");
            idDialog.setHeaderText("Escribe el ID del usuario");
            idDialog.showAndWait();
            String id = idDialog.getEditor().getText();

            TextInputDialog usernameDialog = new TextInputDialog("Username");
            usernameDialog.setHeaderText("Escribe el username del usuario");
            usernameDialog.showAndWait();
            String username = usernameDialog.getEditor().getText();

            TextInputDialog scoreDialog = new TextInputDialog("Score");
            scoreDialog.setHeaderText("Escribe el puntaje del usuario");
            scoreDialog.showAndWait();
            double score = Double.parseDouble(scoreDialog.getEditor().getText());

            User newuser = new User(id, username, score);
            UserData.getInstance().getUsers().add(newuser);
        }catch (Exception ex){
            ex.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Fatal error");
            alert.setContentText("¡Usted se ha equivocado!");
            alert.showAndWait();
        }

    }

    @FXML
    void closeApp(ActionEvent event) {

    }
}
